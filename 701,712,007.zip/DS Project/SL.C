#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>

typedef struct node
{
 char word[20],meaning[100];
 node *left,*right;
}node; //structure of each word with its meaning

void clrscr()
{
system("cls");//Clear Screen
}

int checkString(char c[])
{
if(c[0]==' ')
	{	printf("\nCANNOT START WITH SPACE!");	return 1;	}
else if(c[0]=='\0')
	{	printf("\nCANNOT BE EMPTY!");	return 2; }
else
	return 0;
}// Checking the input string whether it is empty or not

void saveFile(node *tree)
{
FILE *f = fopen("Words.txt","a");
if(f==NULL)
	printf("CANNOT OPEN FILE FOR WRITING!");
else if(tree!=NULL)
{
	fprintf(f,"%s:%s|",tree->word,tree->meaning);
	fclose(f);
	saveFile(tree->left);
	saveFile(tree->right);
}
}//Saving the entered the word with meaning in a file in append mode

node* makeTree(char w[],char m[])
{
node* p = (node*)malloc(sizeof(node));
strcpy(p->word,w);
strcpy(p->meaning,m);
p->left=NULL;
p->right=NULL;
return p;
} // Creating tree dynamically using Linked list

void insert(node *tree,char word[],char meaning[])
{
struct node *p,*q;
p=q=tree;
while(p!=NULL)
{
	q=p;
	if(strcasecmp(word,p->word)<0)
		p=p->left;
	else
		p=p->right;
}
if(strcasecmp(word,q->word)<0)
	q->left=makeTree(word,meaning);
else
	q->right=makeTree(word,meaning);
} // Inserting node into the tree

node* minValue(node* tree)
{
	node* current = tree;
	while(current->left!=NULL)
			current=current->left;
	return current;
} //Searching for the first letters of the word in the whole file and tree

node* deleteWord(node *tree, char word[])
{
	if(tree== NULL)
		return tree;
	if(strcasecmp(word,tree->word)<0)
		tree->left=deleteWord(tree->left,word);
	else if(strcasecmp(word,tree->word)>0)
		tree->right=deleteWord(tree->right,word);
	else
	{
		if(tree->left==NULL)
		{
			node *temp = tree->right;
			free(tree);
			return temp;
		}
		else if(tree->right==NULL)
		{
			node *temp = tree->left;
			free(tree);
			return temp;
		}
		node *temp=minValue(tree->right);
		strcpy(tree->word,temp->word);
		tree->right=deleteWord(tree->right,temp->word);
	}
	return tree;
}//Deleting a word from the tree and the file if saved

node* treeFromFile()
{
node *ptree=NULL;
char word[20],meaning[100],str[5000];
FILE *f = fopen("Words.txt","r");
if(f==NULL)
	return NULL;
else
{
	long begin = ftell(f);
	fseek (f,0,SEEK_END);
	long end = ftell(f);
	fseek (f,0,SEEK_SET);
	long pos=(end-begin);
	fread(str,pos,1,f);
	if(str==NULL)
	return NULL;
	int j=0,i=0,l,f=0,p=0,q=0,flags=0;
	char str1[5000],w[50],m[50];
	l=strlen(str);
	while(i<l)
	{
		if(str[i]!='|')
		{
			str1[j]=str[i];
			j++;
		}
		else
		{
			str1[j]='\0';
			j=0;
			strcpy(w,"");
			strcpy(m,"");
			printf("%s",str1);
			f=q=p=0;
			for(int k=0;str1[k]!='\0';k++)
			{
				if(str1[k]!=':' && f==0)
				{
					w[p]=str1[k];
					p++;
				}
				else
				{
					if(f==0)
						k++;
						m[q]=str1[k];
						q++;
						f=1;
				}
			}
			w[p]='\0';
			m[q]='\0';
			strcpy(str1,"");
			if(flags==0)
			{
				ptree=makeTree(w,m);
				flags=1;
			}
			else
				insert(ptree,w,m);

		}
		i++;
	}
}
fclose(f);
return ptree;
}//Retrieving words from file and converting it in the form of tree for program use.

void displayAll(node *tree)
{
	if(tree!=NULL)
	{
		displayAll(tree->left);
		printf("%s : %s\n",tree->word,tree->meaning);
		displayAll(tree->right);
	}
}//Displaying all nodes of the tree

void letterPrint(node *tree, char letter[])
{
	if(tree!=NULL)
	{
		letterPrint(tree->left,letter);
		if(tree->word[0]==letter[0])
			{	printf("\n%s : %s",tree->word,tree->meaning);	}
		letterPrint(tree->right,letter);
	}
}//Priting the letter and the meaning of the word

int searchLetter(node *tree,char letter[])
{
node *q;
q=tree;
char w[2];
w[0]=q->word[0];
w[1]='\0';
while(q!=NULL)
{
	if(strcasecmp(letter,w)==0)
		{ return 1;	}
	else if(strcasecmp(letter,w)<0)
		{	q=q->left; }
	else
		{
			if(strcasecmp(letter,w)>0)
			{	q=q->right; }
		}
		if(q->word==NULL)
			return 0;
		else
		{
		w[0]=q->word[0];
		w[1]='\0';		}
}
return 0;
}// Searching the letter in the tree.

void display(node *tree, char letter[])
{
if(searchLetter(tree,letter)==1)
	letterPrint(tree,letter);
else
	printf("\nNO WORDS STARTING BY THE LETTER '%s' EXIST",letter);
}//Displaying the word with meaning

node* search(node *tree,char word[])
{
node *q;
q=tree;
while(q!=NULL)
{
	if(strcasecmp(word,q->word)<0)
		q=q->left;
	else if(strcasecmp(word,q->word)>0)
		q=q->right;
	if(strcasecmp(word,q->word)==0)
	break;
}
return q;
}//Searching the tree

void replaceWord(node *tree,char nword[],char word[])
{
node *q;
q=tree;
while(q!=NULL)
{
	if(strcasecmp(word,q->word)<0)
		q=q->left;
	else if(strcasecmp(word,q->word)>0)
		q=q->right;
	if(strcasecmp(word,q->word)==0)
		break;
}
strcpy(q->word,nword);
printf("DONE!");
saveFile(tree);
}//Replacing the existing word in the tree

void replaceMeaning(node *tree,char nmeaning[],char word[])
{
node *q;
q=tree;
while(q!=NULL)
{
	if(strcasecmp(word,q->word)<0)
		q=q->left;
	else if(strcasecmp(word,q->word)>0)
		q=q->right;
	if(strcasecmp(word,q->word)==0)
		break;
}
strcpy(q->meaning,nmeaning);
printf("DONE!");
saveFile(tree);
}//Replacing the meaning of the word in the tree

void intro()
{
clrscr();
printf("ENGLISH LANGUAGE DICTIONARY");
printf("\n----------------");
printf("\nPROJECT BY,\n\tHarshit [01FB17ECS712] \n\tAkilesh [01FB17ECS701]\n\tAbdul [01FB16ECS007]");
getch();
}//Introduction of our project with team members

void prog() //Providing Interface for Dictionary app to the user
{
clrscr();
char word[50],meaning[50],letter[1],nword[50];
int choice1=0, choice2=0;
int rval;
node *temp;
temp= treeFromFile();
for(;;)
{
printf("\nENGLISH LANGUAGE DICTIONARY");
printf("\n--------------------");
printf("\nSELECT CHOICE");
printf("\n1.INSERT 2.REPLACE 3.DELETE 4.SEARCH 5.DISPLAY 6.DISPLAY ALL 7.SAVE 8.CLOSE\n");
scanf("%d",&choice1);
	switch(choice1)
	{
		case 1:
			{
			//INSERT
			printf("\nENTER WORD : ");
			fflush(stdin); gets(word);
			rval=checkString(word);
			if(rval == 0)
			{
				if(search(temp,word)==NULL)
					{
						printf("\nENTER MEANING OF %s : ",word);
						gets(meaning);
						rval=checkString(meaning);
						if(rval == 0)
						{
							if(temp==NULL)
								temp=makeTree(word,meaning);
      						else
      							insert(temp,word,meaning);
						}
					}
				else
					printf("\nWORD ALREADY EXISTS");
			}
			break;
			}
		case 2:
			{
			//REPLACE
			printf("\nENTER WORD ON WHICH REPLACE OPERATION HAS TO BE PERFORMED : ");
			fflush(stdin); gets(word);
			rval=checkString(word);
			if(rval == 0)
			{
				if(search(temp,word)!=NULL)
				{
					printf("\nSELECT CHOICE");
					printf("\n1.REPLACE WORD 2.REPLACE MEANING 3. REPLACE BOTH 4.CANCEL\n");
					scanf("%d",&choice2);
					switch(choice2)
					{
						case 1:
							printf("\nENTER NEW WORD : ");
							fflush(stdin); gets(nword);
							rval=checkString(nword);
							if(rval == 0)
								replaceWord(temp,nword,word);
						break;
						case 2:
							printf("\nENTER NEW MEANING : ");
							fflush(stdin); gets(meaning);
							rval=checkString(meaning);
							if(rval == 0)
								replaceMeaning(temp,meaning,word);
						break;
						case 3:
							printf("\nENTER NEW WORD : ");
							fflush(stdin); gets(nword);
							rval=checkString(nword);
							if(rval == 0)
							{
								printf("\nENTER NEW MEANING : ");
								fflush(stdin); gets(meaning);
								rval=checkString(meaning);
								if(rval == 0)
								{
									replaceMeaning(temp,meaning,word);
									replaceWord(temp,nword,word);
								}
							}
						break;
						default: case 4: break;
					}
				}
				else
					printf("\nWORD DOES NOT EXIST");
			}
			break;
			}
		case 3:
			{
			//DELETE
			printf("\nENTER THE WORD TO BE DELETED : ");
			fflush(stdin); gets(word);
			rval=checkString(word);
			if(rval == 0)
			{
				if(search(temp,word)!=NULL)
				{
					temp=deleteWord(temp,word);
				}
				else
					printf("\nWORD DOES NOT EXIST");
			}
			break;
		case 4:
			//SEARCH
			if(temp==NULL)
				printf("\nEMPTY DICTIONARY");
			else
			printf("\nENTER WORD TO BE SEARCHED : ");
			fflush(stdin); gets(word);
			rval=checkString(word);
			if(rval == 0)
				{
					node *s;
					s=search(temp,word);
					if(s==NULL)
						printf("\nWORD DOES NOT EXIST!");
					else
					{
						printf("\n%s : %s",s->word,s->meaning);
					}
				}
			getch();
			break;
			}
		case 5:
			{
			//DISPLAY
			if(temp==NULL)
				printf("\nEMPTY DICTIONARY");
			else
				printf("\nENTER FIRST LETTER\n");
				fflush(stdin); gets(letter);
				rval=checkString(letter);
				if(rval == 0)
					display(temp,letter);
			getch();
			break;
			}
		case 6:
			{
			//DISPLAY ALL
			if(temp==NULL)
				printf("\nEMPTY DICTIONARY");
			else
				displayAll(temp);
			getch();
			break;
			}
		case 7:
			{
			FILE *f = fopen("Words.txt","w");
			fclose(f);
			saveFile(temp);
			printf("\nSAVE COMPLETE!");
			break;
			}
		case 8: default:
			{
			FILE *f = fopen("Words.txt","w");
			fclose(f);
			saveFile(temp);
			printf("\nCLOSING!");
			exit(0);
			break;
			}
	}
}
}

int main()
{
intro();
prog();
}//Main program where execution starts.
